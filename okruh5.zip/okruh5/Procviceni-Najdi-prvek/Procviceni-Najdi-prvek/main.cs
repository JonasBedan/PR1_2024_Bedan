using System;

class MainClass {
  public static void Main (string[] args) {
    int[] cisla = new int[] {-11, 0, 5, -12, 13, 24, 19, 13, -17};
    //sem přijde váš kód
  }
}