using System;

class MainClass {
    public static void Main (string[] args) 
    {   
        
        int[] cisla = { 1, -5, 0, 4, 0, 7, 12, 0, 4 };

        
        Console.WriteLine(String.Join(", ", cisla2));        
    }
}