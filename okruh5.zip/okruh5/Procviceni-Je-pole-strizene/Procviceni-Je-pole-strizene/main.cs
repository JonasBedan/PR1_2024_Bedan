using System;

class MainClass {
    public static void Main (string[] args) {
        
        // Zkuste jednu některou deklaraci zakomentovat a jinou odkomentovat
        // váš kód by měl dát pro všechny správnou odpověď
        
        double[] cisla = { -5, 4.3, 2.7, 6.41, 12 }; //není
        //double[] cisla = { -5, 2.7, 4.3, 6.41, 12 }; //je
        //double[] cisla = { -5, 2.7, 2.7, 4.3, 6.41, 12 }; //je
    
        //sem přijde váš kód
    }
}