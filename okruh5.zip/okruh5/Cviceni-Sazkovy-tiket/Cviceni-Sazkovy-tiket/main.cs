using System;

class Program
{
    public static void Main(string[] args)
    {

        int[] sportka = new int[] { 9, 5, 6, 1, 5, 6 };
    }
}