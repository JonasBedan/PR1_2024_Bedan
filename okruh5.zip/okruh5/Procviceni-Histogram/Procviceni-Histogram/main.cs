using System;

class MainClass {
    public static void Main (string[] args) {
        int[] hodnoty = {1, 3, 2, 4, 7, 12, 4};
        
        //zde pokračujte
    }
}