using System;

class MainClass {
    public static void Main (string[] args) {
        string text = "Statný valach ojnici zničil. Révou zhrdla žena ostrovana Claudia Pompeia. Ozvučení hnědé místnosti okamžitě zvýraznit! Běžný statkář to zvládne. Japonec Anihito rád označoval čárami. Asi sto pět kravských žaludků";
    }
}