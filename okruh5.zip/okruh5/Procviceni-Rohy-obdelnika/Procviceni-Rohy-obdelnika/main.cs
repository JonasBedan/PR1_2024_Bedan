using System;

class MainClass {
    public static void Main (string[] args) {
        int[] levyHorni = { -1, 2 };
        int[] rozmery = { 2, 3 };
        
        // doplňte
        
        // int[] pravyHorni =
        // int[] levyDolni =
        // int[] pravyDolni =
        
        // vypište
    }
}