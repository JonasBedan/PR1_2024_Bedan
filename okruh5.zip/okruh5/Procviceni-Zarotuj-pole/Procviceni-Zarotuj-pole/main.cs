using System;

class MainClass {
    public static void Main (string[] args) {
        int[] cisla = { -6, -7, -1, 3, 0, 1, 5, 9, 8, 10 };
    }
}