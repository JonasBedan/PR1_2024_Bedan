using System;

class MainClass {
  public static void Main (string[] args) {
    int n = 5000;
    int k = 3;
  }
}