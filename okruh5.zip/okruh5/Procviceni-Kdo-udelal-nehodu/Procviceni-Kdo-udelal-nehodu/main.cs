using System;

class MainClass {
    public static void Main (string[] args) {
        
        int[] jizdy = {
            247,
            135,
            15,
            23,
            428,
            63,
            26,
            7
        };
        
        string[] ridici = {
            "Petr",
            "Pavel",
            "Jaroslav",
            "Pavel",
            "Jaroslav",
            "Petr",
            "Pavel",
            "Petr"
        };
        
        int prestupek = 401;
        
        //sem přijde váš kód
    }
}