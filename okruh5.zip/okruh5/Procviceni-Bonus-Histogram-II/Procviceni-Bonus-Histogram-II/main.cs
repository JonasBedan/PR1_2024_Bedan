using System;
using System.Linq;

class MainClass {
    public static void Main (string[] args) {
        int[] hodnoty = {100, 300, 200, 400, 700, 1200, 400};
        int delkaRadky = 80;

        //zde pokračujte
    }
}