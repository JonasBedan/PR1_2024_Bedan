using System;

class MainClass {
  public static void Main (string[] args) {
    int n = 1000; //vyzkoušejte i jiné možnosti
    int k = 2; //vyzkoušejte i jiné možnosti
    
    //zde pokračujte


  }
}