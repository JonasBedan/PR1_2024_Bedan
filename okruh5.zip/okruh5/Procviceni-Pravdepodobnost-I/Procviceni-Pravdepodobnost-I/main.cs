using System;

class MainClass {
  public static void Main (string[] args) {
    int n = 1000;
  }
}