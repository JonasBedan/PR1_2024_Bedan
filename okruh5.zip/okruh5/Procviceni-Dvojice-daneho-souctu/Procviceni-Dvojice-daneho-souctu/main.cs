using System;

class MainClass {
    public static void Main (string[] args) {
        int[] cisla = { -6, 10, -7, -2, -14,  11, 9 };
        int soucet = 4;
        
        //sem přijde váš kód
    }
}