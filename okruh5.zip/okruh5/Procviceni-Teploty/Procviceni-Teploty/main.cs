using System;

class MainClass {
  public static void Main (string[] args) {
    double[] teploty = {13.7, 14.2, 14.3, 14.8, 15.2, 16.0, 16.3, 17.1};
    //sem přijde váš kód
   

  }
}