using System;

namespace ObdelnikProject 
{
    class Obdelnik 
    {
        //Sem doplňte váš kód   
    }
}