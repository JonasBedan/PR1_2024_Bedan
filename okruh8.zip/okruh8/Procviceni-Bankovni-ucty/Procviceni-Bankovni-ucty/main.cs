using System;

namespace Bank
{
    class MainClass
    {
        public static void Main(string[] args)
        {

        }
    }
}