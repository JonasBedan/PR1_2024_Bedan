using System;

namespace Bank {

    class BankAccount 
    {
   
    }

}