using System;

class MainClass {
    public static void Main (string[] args) {
        //vytvořte první CD a vypište jeho popis

        
        //vytvořte druhé CD a vypište jeho popis
    }
}