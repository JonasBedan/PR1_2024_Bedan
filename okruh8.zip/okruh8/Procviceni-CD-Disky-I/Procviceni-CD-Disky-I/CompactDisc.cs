using System;

class CompactDisc
{
    
}