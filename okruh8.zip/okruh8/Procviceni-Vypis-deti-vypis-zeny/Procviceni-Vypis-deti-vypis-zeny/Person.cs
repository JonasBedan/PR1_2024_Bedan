using System;

namespace PersonProject
{
    enum SexType : byte { Male, Female }

    class Person
    {
        public string Name;
        public string Surname;
        public int Age;
        public SexType Sex; 

        public string IntroduceSelf() 
        {
            //zde je zatím výjimka, která říká "ještě není hotovo" - nahraďte ji správným kódem
            throw new NotImplementedException();
        }
    }
}