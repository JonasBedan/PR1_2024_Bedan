using System;

class Polozka
{
    public string Nazev;
    public int Pocet;

}