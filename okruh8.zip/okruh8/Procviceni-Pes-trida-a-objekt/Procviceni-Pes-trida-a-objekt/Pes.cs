using System;

namespace PesProjekt
{

    class Pes
    {
        //sem přijde váš kód
    }

}