using System;

namespace ObdelnikProject 
{
    class Obdelnik
    {
        
    }
}