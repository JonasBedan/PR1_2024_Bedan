using System;

namespace NadobaProject
{
    class Nadoba
    {
        //to be implemented
    }
}