using System;

namespace NadobaProject
{
    class MainClass 
    {
        public static void Main (string[] args) {
            
            // až bude třída implementovaná, zde si s nádobami pohrajte
            
            Nadoba trilitrak = new Nadoba(3);
            trilitrak.Napln();

            Nadoba petilitrak = new Nadoba(5);
            trilitrak.PrelejDo(petilitrak);

            Console.WriteLine(trilitrak);
            Console.WriteLine(petilitrak);
            Console.WriteLine($"V pětilitrovém hrnci je ještě místo na {petilitrak.VolnyObjem} litrů vody.");
        }
    }
}