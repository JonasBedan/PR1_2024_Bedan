using System;

namespace PesProject {

    class Pes 
    {
        public string Jmeno;
        public int Nohy;
        public bool JeOckovany;

        public string PredstavSe() 
        {
            return $"Já jsem pes, jmenuju se {Jmeno}, mám {Nohy} nohy a {(JeOckovany ? "jsem":"nejsem")} očkovaný.";
        }
    }

}