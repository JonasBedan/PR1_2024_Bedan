using System;
using System.Linq;

namespace CokoladaProject 
{
    class Tabulka 
    {
        //sem přijde kód třídy
    }
}