using System;

class MainClass {
    public static void Main (string[] args) {
        bool[,] mapa = VytvorMapu(8, 12, 30);
        VykresliPole(mapa, '#', ' ');
    }

    static bool[,] VytvorMapu(int vyska, int sirka, int pocetMinci)
    {
        //sem přijde váš kód pro tuto úlohu
    }

    //sem si vložte překopírovanou metodu VykresliPole z úlohy 07 / 020
}