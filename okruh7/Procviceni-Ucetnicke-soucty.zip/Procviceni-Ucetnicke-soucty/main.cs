using System;

class MainClass {
    public static void Main (string[] args) {
        int[,] cisla = {
            {1, 0, 10, 4, 7},
            {2, 2, 3, 4, 2},
            {6, 5, 4, 3, 2}
        };  

        Ucetni(cisla);
        Console.WriteLine();


        int[,] cisla2 = {
            {1, 0, 10, 4},
            {2, 2, 3, 4},
            {6, 5, 4, 3},
            {12, 0, 0, -1}
        };
        Ucetni(cisla2);

    }

    public static void Ucetni(int[,] poleCisel)
    {
        //sem přijde váš kód
    }
