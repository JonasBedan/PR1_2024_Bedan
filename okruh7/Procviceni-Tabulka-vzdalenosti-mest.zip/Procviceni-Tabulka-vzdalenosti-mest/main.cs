using System;

class MainClass {
    public static void Main (string[] args) {
        
        Mapa mapa = new Mapa();

        //do proměnné města uložíme všechna města z mapy
        string[] mesta = mapa.Rejstrik;
        //můžeme je i vypsat
        Console.WriteLine(String.Join(", ", mesta));

        //chceme-li zjistit vzdálenost dvou měst, zeptáme se na ni naší mapy takto
        double vzdalenost12 = mapa.Vzdalenost(1, 3);

        //takto bychom ji vypsali
        Console.WriteLine($"Vzdálenost {mesta[1]} a {mesta[2]} je {vzdalenost12} km");

        //nyní seskládejte a vypište tabulku vzdáleností
        
    }
}