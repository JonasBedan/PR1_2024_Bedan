using System;

class MainClass {
    public static void Main (string[] args) {
        int[,] cisla = {
            {1, 0, 10, 4, 7},
            {2, 2, 3, 4, 2},
            {6, 5, 4, 3, 2}
        };

        VypisTabulku(cisla);

        Console.WriteLine();

        int[,] cisla2 = {
            {1, 0, 10, 4},
            {2, 2, 3, 4},
            {6, 5, 4, 3},
            {12, 0, 0, -1}
        };
        
        VypisTabulku(cisla2);
    }

    //zde vložte kód metody
}