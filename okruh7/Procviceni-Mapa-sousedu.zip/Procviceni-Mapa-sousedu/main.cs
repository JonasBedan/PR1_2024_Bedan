using System;

class MainClass {
    public static void Main (string[] args) {
        bool[,] mapa1 =  
        {
            { true,  true,  false, false },
            { false, false, true,  true },
            { false, false, false, true },
            { false, false, true,  true },
        };

        Vypis2DPole(Sousede(mapa1));
        Console.WriteLine();

        bool[,] mapa2 =  
        {
            { true,  true,  false, false, true },
            { false, false, true,  true,  false },
            { false, false, false, true,  false },
        };        

        Vypis2DPole(Sousede(mapa2));
    }

    //sem dejte kód metody Sousede, dle zadání která dostává 2D pole typu bool a vrací 2D pole typu int





    //zde končí váš kód

    public static void Vypis2DPole(int[,] pole)
    {
        //do kódu této metody nezasahujte - nebo si můžete doplnit rámečky jako v jedné z předešlých úloh
        for (int y = 0; y < pole.GetLength(0); y++)
        {
            for (int x = 0; x < pole.GetLength(1); x++)
            {
                Console.Write(pole[y, x]);
                Console.Write(" ");
            }
            Console.WriteLine();
        }
    } 
}